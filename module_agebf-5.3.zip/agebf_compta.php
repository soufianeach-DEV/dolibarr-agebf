<?php
/* Copyright (C) 2026 Bruxelles Formation — Module AgeBF/Helpy */

$res = 0;
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) {
	$res = @include $_SERVER["CONTEXT_DOCUMENT_ROOT"]."/main.inc.php";
}
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME']; $tmp2 = realpath(__FILE__); $i = strlen($tmp) - 1; $j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) { $i--; $j--; }
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1))."/main.inc.php")) { $res = @include substr($tmp, 0, ($i + 1))."/main.inc.php"; }
if (!$res && file_exists("../main.inc.php")) { $res = @include "../main.inc.php"; }
if (!$res && file_exists("../../main.inc.php")) { $res = @include "../../main.inc.php"; }
if (!$res) { die("Include of main fails"); }

// ── Paramètres ────────────────────────────────────────────────────────────────
$annee        = (int) GETPOST('annee',        'int');
$s_rapproche  = GETPOST('s_rapproche',        'aZ09');
$s_sepa       = trim(GETPOST('s_sepa',        'alphanohtml'));
$export       = GETPOST('export',             'aZ09');
$action       = GETPOST('action',             'aZ09');
$open_fac     = (int) GETPOST('open_fac',     'int');
$type_facture = GETPOST('type_facture',       'aZ09');

if ($annee < 2020 || $annee > 2100) $annee = (int) date('Y');
if (!in_array($s_rapproche, ['tous', 'oui', 'non'])) $s_rapproche = 'tous';
if (!in_array($type_facture, ['tous', 'client', 'fournisseur'])) $type_facture = 'fournisseur';

$sortfield    = GETPOST('sortfield', 'aZ09');
$sortorder    = GETPOST('sortorder', 'aZ09');
$allowed_sort = ['s.nom', 'f.ref', 'f.total_ttc', 'deja_paye', 'restant', 'nb_versements', 'nb_rapproche'];
if (!in_array($sortfield, $allowed_sort))               $sortfield = 's.nom';
if (!in_array(strtoupper($sortorder), ['ASC', 'DESC'])) $sortorder = 'ASC';

function compta_sort_link(string $label, string $field, string $sf, string $so, string $base, int $annee, string $rapproche, string $sepa, string $type_fac = 'fournisseur'): string {
    $new_order = ($sf === $field && $so === 'ASC') ? 'DESC' : 'ASC';
    $arrow = ($sf === $field) ? ($so === 'ASC' ? ' <span style="color:#e67e22">&#9650;</span>' : ' <span style="color:#e67e22">&#9660;</span>') : ' <span style="color:#999;font-size:0.75em">&#9650;&#9660;</span>';
    $url = $base . '?annee=' . $annee
         . '&s_rapproche=' . urlencode($rapproche)
         . ($sepa !== '' ? '&s_sepa=' . urlencode($sepa) : '')
         . '&type_facture=' . urlencode($type_fac)
         . '&sortfield=' . urlencode($field) . '&sortorder=' . $new_order;
    return '<a href="' . $url . '" style="color:inherit;text-decoration:none;cursor:pointer">' . $label . $arrow . '</a>';
}

$url_base = DOL_URL_ROOT . '/custom/agebf/agebf_compta.php';
$msg_ok  = '';
$msg_err = '';

if (GETPOST('rapproche_ok', 'int') == 1) {
	$msg_ok = 'Paiement rapproche avec succes &mdash; releve : <b>' . dol_escape_htmltag(GETPOST('releve_ok', 'nohtml')) . '</b>';
}
if (GETPOST('derapproche_ok', 'int') == 1) {
	$msg_ok = 'Rapprochement annule.';
}
if (GETPOSTISSET('belfius_ok')) {
	$nb_b = (int) GETPOST('belfius_ok', 'int');
	$nb_l = (int) GETPOST('belfius_lots', 'int');
	$msg_ok = $nb_b > 0
		? '<b>' . $nb_b . '</b> virement(s) rapproch&eacute;(s) automatiquement depuis le relev&eacute; Belfius, sur <b>' . $nb_l . '</b> lot(s) SEPA.'
		: 'Aucun virement rapproch&eacute; (aucun lot coch&eacute; ou d&eacute;j&agrave; tout rapproch&eacute;).';
}

// ── Action : rapprocher un paiement ──────────────────────────────────────────
if ($action === 'rapprocher' && !empty($_POST['token'])) {
	$pay_id   = (int) GETPOST('pay_id',    'int');
	$num_rel  = trim(GETPOST('num_releve', 'alphanohtml'));
	$pay_type = GETPOST('pay_type',        'aZ09'); // 'client' ou 'fournisseur'

	if ($pay_id > 0) {
		if ($pay_type === 'client') {
			$sql_bk = "SELECT b.rowid FROM " . MAIN_DB_PREFIX . "bank b"
			        . " INNER JOIN " . MAIN_DB_PREFIX . "paiement pay ON pay.fk_bank = b.rowid"
			        . " WHERE pay.rowid = " . $pay_id . " LIMIT 1";
		} else {
			$sql_bk = "SELECT b.rowid FROM " . MAIN_DB_PREFIX . "bank b"
			        . " INNER JOIN " . MAIN_DB_PREFIX . "paiementfourn pay ON pay.fk_bank = b.rowid"
			        . " WHERE pay.rowid = " . $pay_id . " LIMIT 1";
		}
		$rbk = $db->query($sql_bk);
		if ($rbk && ($obk = $db->fetch_object($rbk))) {
			$bank_id = (int) $obk->rowid;
			$sql_up  = "UPDATE " . MAIN_DB_PREFIX . "bank"
			         . " SET rappro = 1"
			         . ($num_rel !== '' ? ", num_releve = '" . $db->escape($num_rel) . "'" : "")
			         . " WHERE rowid = " . $bank_id;
			if ($db->query($sql_up)) {
				header('Location: ' . $url_base . '?annee=' . $annee . '&s_rapproche=' . urlencode($s_rapproche)
				     . '&s_sepa=' . urlencode($s_sepa) . '&type_facture=' . urlencode($type_facture)
				     . '&open_fac=' . (int) GETPOST('fac_id', 'int')
				     . '&rapproche_ok=1&releve_ok=' . urlencode($num_rel));
				exit;
			} else {
				$msg_err = 'Erreur lors du rapprochement : ' . $db->lasterror();
			}
		} else {
			$msg_err = 'Aucune ecriture bancaire trouvee pour ce paiement. Verifiez que le paiement est bien lie a un compte bancaire dans Dolibarr.';
		}
	}
}

// ── Action : annuler un rapprochement (admin uniquement) ─────────────────────
if ($action === 'derapprocher' && $user->admin && !empty($_POST['token'])) {
	$pay_id   = (int) GETPOST('pay_id', 'int');
	$pay_type = GETPOST('pay_type',     'aZ09');

	if ($pay_id > 0) {
		if ($pay_type === 'client') {
			$sql_bk = "SELECT b.rowid FROM " . MAIN_DB_PREFIX . "bank b"
			        . " INNER JOIN " . MAIN_DB_PREFIX . "paiement pay ON pay.fk_bank = b.rowid"
			        . " WHERE pay.rowid = " . $pay_id . " LIMIT 1";
		} else {
			$sql_bk = "SELECT b.rowid FROM " . MAIN_DB_PREFIX . "bank b"
			        . " INNER JOIN " . MAIN_DB_PREFIX . "paiementfourn pay ON pay.fk_bank = b.rowid"
			        . " WHERE pay.rowid = " . $pay_id . " LIMIT 1";
		}
		$rbk = $db->query($sql_bk);
		if ($rbk && ($obk = $db->fetch_object($rbk))) {
			$sql_up = "UPDATE " . MAIN_DB_PREFIX . "bank SET rappro = 0 WHERE rowid = " . (int)$obk->rowid;
			if ($db->query($sql_up)) {
				header('Location: ' . $url_base . '?annee=' . $annee . '&s_rapproche=' . urlencode($s_rapproche)
				     . '&s_sepa=' . urlencode($s_sepa) . '&type_facture=' . urlencode($type_facture)
				     . '&open_fac=' . (int) GETPOST('fac_id', 'int')
				     . '&derapproche_ok=1');
				exit;
			} else {
				$msg_err = 'Erreur lors de l\'annulation : ' . $db->lasterror();
			}
		}
	}
}

// ── Action : appliquer les rapprochements validés de l'import Belfius (par lot) ─
if ($action === 'apply_belfius' && !empty($_POST['token'])) {
	$sel_bon = isset($_POST['sel_bon'])    && is_array($_POST['sel_bon'])    ? $_POST['sel_bon']    : [];
	$sel_rel = isset($_POST['sel_releve']) && is_array($_POST['sel_releve']) ? $_POST['sel_releve'] : [];
	$apply   = isset($_POST['apply'])      && is_array($_POST['apply'])      ? $_POST['apply']      : [];
	$lots    = bf_load_lots($db);
	$nb_ok   = 0;
	$nb_lots = 0;
	foreach ($apply as $idx => $on) {
		$bon = isset($sel_bon[$idx]) ? (int) $sel_bon[$idx] : 0;
		$rel = isset($sel_rel[$idx]) ? trim((string) $sel_rel[$idx]) : '';
		if ($bon <= 0 || !isset($lots[$bon])) continue;
		$bank_ids = [];
		foreach ($lots[$bon]->virements as $v) {
			if ($v->bank_id > 0 && !$v->rappro) $bank_ids[] = (int) $v->bank_id;
		}
		if (empty($bank_ids)) continue;
		$up = "UPDATE " . MAIN_DB_PREFIX . "bank SET rappro = 1"
		    . ($rel !== '' ? ", num_releve = '" . $db->escape($rel) . "'" : "")
		    . " WHERE rowid IN (" . implode(',', $bank_ids) . ")";
		if ($db->query($up)) { $nb_ok += count($bank_ids); $nb_lots++; }
	}
	header('Location: ' . $url_base . '?annee=' . $annee . '&type_facture=fournisseur&belfius_ok=' . $nb_ok . '&belfius_lots=' . $nb_lots);
	exit;
}

// ── Helpers : import / parsing du relevé Belfius ──────────────────────────────
function bf_norm($s) {
	$s = mb_strtolower(trim((string) $s), 'UTF-8');
	$s = strtr($s, [
		'à'=>'a','â'=>'a','ä'=>'a','é'=>'e','è'=>'e','ê'=>'e','ë'=>'e',
		'î'=>'i','ï'=>'i','ô'=>'o','ö'=>'o','ù'=>'u','û'=>'u','ü'=>'u','ç'=>'c',
	]);
	return preg_replace('/\s+/', ' ', $s);
}
function bf_parse_belfius($path) {
	$raw = @file_get_contents($path);
	if ($raw === false || $raw === '') return null;
	if (!mb_check_encoding($raw, 'UTF-8')) $raw = mb_convert_encoding($raw, 'UTF-8', 'ISO-8859-1');
	$lines = preg_split('/\r\n|\r|\n/', $raw);
	$hdr = null; $map = []; $out = [];
	foreach ($lines as $ln) {
		if (trim($ln) === '') continue;
		$cells = str_getcsv($ln, ';', '"');
		if ($hdr === null) {
			$norm   = array_map('bf_norm', $cells);
			$joined = implode('|', $norm);
			$has_montant = (strpos($joined, 'montant') !== false || strpos($joined, 'bedrag') !== false);
			$has_comm    = (strpos($joined, 'communication') !== false || strpos($joined, 'mededeling') !== false
			             || strpos($joined, 'comptabilisation') !== false || strpos($joined, 'boekingsdatum') !== false);
			if (count($cells) >= 5 && $has_montant && $has_comm) {
				$hdr = $norm;
				foreach ($hdr as $i => $h) {
					if (strpos($h, 'comptabilisation') !== false || strpos($h, 'boekingsdatum') !== false) $map['date'] = $i;
					elseif (strpos($h, 'extrait') !== false || strpos($h, 'afschrift') !== false)         $map['extrait'] = $i;
					elseif (strpos($h, 'montant') !== false || strpos($h, 'bedrag') !== false)            $map['montant'] = $i;
					elseif (strpos($h, 'communication') !== false || strpos($h, 'mededeling') !== false)  $map['comm'] = $i;
					elseif ((strpos($h, 'contrepartie') !== false || strpos($h, 'tegenpartij') !== false) && strpos($h, 'compte') === false && strpos($h, 'rekening') === false) $map['name'] = $i;
				}
			}
			continue;
		}
		if (count($cells) < 3 || !isset($map['montant'])) continue;
		$gc = function ($k) use ($cells, $map) { return (isset($map[$k]) && isset($cells[$map[$k]])) ? trim($cells[$map[$k]]) : ''; };
		$mraw = $gc('montant');
		if ($mraw === '' || !preg_match('/\d/', $mraw)) continue;
		$mf  = (float) str_replace(',', '.', str_replace('.', '', $mraw));
		$dd  = $gc('date'); $diso = '';
		if (preg_match('#(\d{2})/(\d{2})/(\d{4})#', $dd, $m)) $diso = $m[3] . '-' . $m[2] . '-' . $m[1];
		$ct = 0;
		if (preg_match('#DOL/\d{6,8}/CT0*(\d+)#i', $gc('comm'), $mc)) $ct = (int) $mc[1];
		$out[] = [
			'date_disp' => $dd,
			'date_iso'  => $diso,
			'extrait'   => $gc('extrait'),
			'montant'   => abs($mf),
			'mont_disp' => $mraw,
			'name'      => $gc('name'),
			'comm'      => $gc('comm'),
			'ct'        => $ct,
		];
	}
	return $out;
}

function bf_date_close($a, $b, $tol = 5) {
	if (empty($a) || empty($b)) return false;
	$ta = strtotime($a); $tb = strtotime($b);
	if ($ta === false || $tb === false) return false;
	return abs($ta - $tb) <= $tol * 86400;
}

function bf_load_lots($db) {
	$P = MAIN_DB_PREFIX;
	$entity = (int) $GLOBALS['conf']->entity;
	$db->query("CREATE TABLE IF NOT EXISTS {$P}agebf_lot_sepa ("
	    . " fk_bon integer NOT NULL,"
	    . " msgid varchar(64) DEFAULT NULL,"
	    . " ct_num integer DEFAULT NULL,"
	    . " entity integer NOT NULL DEFAULT 1,"
	    . " PRIMARY KEY (fk_bon)"
	    . ") ENGINE=InnoDB");
	$sql = "SELECT pb.rowid AS bon_id, pb.ref AS lot_ref, pb.amount AS lot_total,
	               DATE_FORMAT(pb.date_credit, '%Y-%m-%d') AS date_op,
	               pay.rowid AS pay_id, pay.num_paiement AS sepa, pay.amount AS montant, pay.fk_bank AS bank_id,
	               COALESCE(b.rappro, 0) AS rappro, COALESCE(b.num_releve, '') AS num_releve,
	               s.nom AS tiers, f.ref AS fac_ref,
	               ls.msgid AS msgid, ls.ct_num AS ct_num
	        FROM {$P}prelevement_bons pb
	        JOIN {$P}paiementfourn pay ON pay.num_paiement = pb.ref AND pay.entity = pb.entity
	        LEFT JOIN {$P}bank b ON b.rowid = pay.fk_bank
	        LEFT JOIN {$P}paiementfourn_facturefourn pff ON pff.fk_paiementfourn = pay.rowid
	        LEFT JOIN {$P}facture_fourn f ON f.rowid = pff.fk_facturefourn
	        LEFT JOIN {$P}societe s ON s.rowid = f.fk_soc
	        LEFT JOIN {$P}agebf_lot_sepa ls ON ls.fk_bon = pb.rowid
	        WHERE pb.type = 'bank-transfer' AND pb.entity = " . $entity . "
	        ORDER BY pb.rowid, pay.rowid";
	$r = $db->query($sql);
	$lots = [];
	if ($r) {
		while ($o = $db->fetch_object($r)) {
			$id = (int) $o->bon_id;
			if (!isset($lots[$id])) {
				$lots[$id] = (object) [
					'bon_id' => $id, 'ref' => $o->lot_ref, 'total' => (float) $o->lot_total,
					'date_op' => $o->date_op, 'virements' => [], '_seen' => [],
					'msgid' => (string) $o->msgid, 'ct_num' => (int) $o->ct_num,
					'nb' => 0, 'nb_rappro' => 0, 'nb_libre' => 0,
				];
			}
			$pid = (int) $o->pay_id;
			if (isset($lots[$id]->_seen[$pid])) {
				if (!empty($o->fac_ref)) {
					$ex = $lots[$id]->_seen[$pid];
					$ex->fac_ref = trim($ex->fac_ref . ' ' . $o->fac_ref);
				}
				continue;
			}
			$v = (object) [
				'bank_id' => (int) $o->bank_id, 'pay_id' => $pid,
				'sepa' => $o->sepa, 'montant' => (float) $o->montant,
				'rappro' => (int) $o->rappro, 'num_releve' => $o->num_releve,
				'fac_ref' => (string) $o->fac_ref, 'tiers' => (string) $o->tiers,
			];
			$lots[$id]->virements[] = $v;
			$lots[$id]->_seen[$pid] = $v;
			$lots[$id]->nb++;
			if ($v->rappro) $lots[$id]->nb_rappro++; else if ($v->bank_id > 0) $lots[$id]->nb_libre++;
		}
		$db->free($r);
	}
	foreach ($lots as $L) { unset($L->_seen); }
	return $lots;
}

// ── Requêtes factures fournisseurs ────────────────────────────────────────────
$factures     = [];
$fac_ids      = [];
$sql_order_base = in_array($sortfield, ['s.nom','f.ref','f.total_ttc'])
    ? $sortfield . ' ' . $sortorder . ($sortfield !== 'f.ref' ? ', f.ref ASC' : '')
    : 's.nom ASC, f.ref ASC';

if ($type_facture !== 'client') {
	$sql = "SELECT DISTINCT
	    f.rowid       AS fac_id,
	    f.ref         AS fac_ref,
	    f.total_ttc   AS total_ttc,
	    f.datef       AS datef,
	    s.rowid       AS soc_id,
	    s.nom         AS tiers_nom
	FROM " . MAIN_DB_PREFIX . "facture_fourn f
	JOIN " . MAIN_DB_PREFIX . "societe s ON s.rowid = f.fk_soc
	JOIN " . MAIN_DB_PREFIX . "paiementfourn_facturefourn pff ON pff.fk_facturefourn = f.rowid
	WHERE f.entity = " . (int)$conf->entity . "
	  AND YEAR(f.datef) = " . (int)$annee . "
	ORDER BY " . $sql_order_base;

	$resql = $db->query($sql);
	if (!$resql) {
		if ($export !== 'csv') { llxHeader(); }
		print '<div class="error">' . $db->lasterror() . '</div>';
		if ($export !== 'csv') { llxFooter(); }
		$db->close(); exit;
	}
	while ($obj = $db->fetch_object($resql)) {
		$obj->payments  = [];
		$obj->packs     = [];
		$obj->deja_paye = 0.0;
		$obj->type      = 'fournisseur';
		$factures[(int)$obj->fac_id] = $obj;
		$fac_ids[] = (int)$obj->fac_id;
	}
	$db->free($resql);
}

if (!empty($fac_ids)) {
	$in = implode(',', array_map('intval', $fac_ids));

	$sql_pay = "SELECT
	    pff.fk_facturefourn                    AS fac_id,
	    pay.rowid                              AS pay_id,
	    pay.datep                              AS date_paiement,
	    COALESCE(pay.num_paiement, '')        AS ref_sepa,
	    pff.amount                             AS montant_paye,
	    COALESCE(b.num_releve, '')            AS num_releve,
	    COALESCE(b.rowid, 0)                  AS bank_id,
	    COALESCE(b.rappro, 0)                 AS rapproche
	FROM " . MAIN_DB_PREFIX . "paiementfourn_facturefourn pff
	JOIN " . MAIN_DB_PREFIX . "paiementfourn pay ON pay.rowid = pff.fk_paiementfourn
	LEFT JOIN " . MAIN_DB_PREFIX . "bank b ON b.rowid = pay.fk_bank
	WHERE pff.fk_facturefourn IN (" . $in . ")
	ORDER BY pay.datep ASC, pay.rowid ASC";

	$rpay = $db->query($sql_pay);
	if ($rpay) {
		while ($p = $db->fetch_object($rpay)) {
			$fid = (int)$p->fac_id;
			if (isset($factures[$fid])) {
				$factures[$fid]->payments[] = $p;
				$factures[$fid]->deja_paye += (float)$p->montant_paye;
			}
		}
		$db->free($rpay);
	}

	$sql_pk = "SELECT DISTINCT
	    fd.fk_facture_fourn AS fac_id,
	    p.ref               AS pack_ref,
	    p.label             AS pack_label
	FROM " . MAIN_DB_PREFIX . "facture_fourn_det fd
	JOIN " . MAIN_DB_PREFIX . "product p ON p.rowid = fd.fk_product
	WHERE fd.fk_facture_fourn IN (" . $in . ")";

	$rpk = $db->query($sql_pk);
	if ($rpk) {
		while ($pk = $db->fetch_object($rpk)) {
			$fid = (int)$pk->fac_id;
			if (isset($factures[$fid])) $factures[$fid]->packs[] = $pk;
		}
		$db->free($rpk);
	}
}

// ── Requêtes factures clients ─────────────────────────────────────────────────
$factures_client = [];
$fac_ids_client  = [];

if ($type_facture !== 'fournisseur') {
	$sql_c = "SELECT DISTINCT
	    f.rowid       AS fac_id,
	    f.ref         AS fac_ref,
	    f.total_ttc   AS total_ttc,
	    f.datef       AS datef,
	    s.rowid       AS soc_id,
	    s.nom         AS tiers_nom
	FROM " . MAIN_DB_PREFIX . "facture f
	JOIN " . MAIN_DB_PREFIX . "societe s ON s.rowid = f.fk_soc
	JOIN " . MAIN_DB_PREFIX . "paiement_facture pf ON pf.fk_facture = f.rowid
	WHERE f.entity = " . (int)$conf->entity . "
	  AND YEAR(f.datef) = " . (int)$annee . "
	ORDER BY " . $sql_order_base;

	$resql_c = $db->query($sql_c);
	if (!$resql_c) {
		if ($export !== 'csv') { llxHeader(); }
		print '<div class="error">' . $db->lasterror() . '</div>';
		if ($export !== 'csv') { llxFooter(); }
		$db->close(); exit;
	}
	while ($obj = $db->fetch_object($resql_c)) {
		$obj->payments  = [];
		$obj->packs     = [];
		$obj->deja_paye = 0.0;
		$obj->type      = 'client';
		$factures_client[(int)$obj->fac_id] = $obj;
		$fac_ids_client[] = (int)$obj->fac_id;
	}
	$db->free($resql_c);
}

if (!empty($fac_ids_client)) {
	$in_c = implode(',', array_map('intval', $fac_ids_client));

	$sql_pay_c = "SELECT
	    pf.fk_facture                          AS fac_id,
	    pay.rowid                              AS pay_id,
	    pay.datep                              AS date_paiement,
	    COALESCE(pay.num_paiement, '')        AS ref_sepa,
	    pf.amount                              AS montant_paye,
	    COALESCE(b.num_releve, '')            AS num_releve,
	    COALESCE(b.rowid, 0)                  AS bank_id,
	    COALESCE(b.rappro, 0)                 AS rapproche
	FROM " . MAIN_DB_PREFIX . "paiement_facture pf
	JOIN " . MAIN_DB_PREFIX . "paiement pay ON pay.rowid = pf.fk_paiement
	LEFT JOIN " . MAIN_DB_PREFIX . "bank b ON b.rowid = pay.fk_bank
	WHERE pf.fk_facture IN (" . $in_c . ")
	ORDER BY pay.datep ASC, pay.rowid ASC";

	$rpay_c = $db->query($sql_pay_c);
	if ($rpay_c) {
		while ($p = $db->fetch_object($rpay_c)) {
			$fid = (int)$p->fac_id;
			if (isset($factures_client[$fid])) {
				$factures_client[$fid]->payments[] = $p;
				$factures_client[$fid]->deja_paye += (float)$p->montant_paye;
			}
		}
		$db->free($rpay_c);
	}

	$sql_pk_c = "SELECT DISTINCT
	    fd.fk_facture AS fac_id,
	    p.ref         AS pack_ref,
	    p.label       AS pack_label
	FROM " . MAIN_DB_PREFIX . "facturedet fd
	JOIN " . MAIN_DB_PREFIX . "product p ON p.rowid = fd.fk_product
	WHERE fd.fk_facture IN (" . $in_c . ")";

	$rpk_c = $db->query($sql_pk_c);
	if ($rpk_c) {
		while ($pk = $db->fetch_object($rpk_c)) {
			$fid = (int)$pk->fac_id;
			if (isset($factures_client[$fid])) $factures_client[$fid]->packs[] = $pk;
		}
		$db->free($rpk_c);
	}
}

// ── Calculs par facture + filtres PHP ─────────────────────────────────────────
$rows = [];

$_apply = function($f) use ($s_sepa, $s_rapproche, &$rows) {
	$f->restant       = (float)$f->total_ttc - $f->deja_paye;
	$f->nb_versements = count($f->payments);
	$f->nb_rapproche  = 0;
	foreach ($f->payments as $p) { if ($p->rapproche) $f->nb_rapproche++; }
	$f->nb_non_rapp   = $f->nb_versements - $f->nb_rapproche;

	if ($s_sepa !== '') {
		$match = false;
		foreach ($f->payments as $p) {
			if (stripos($p->ref_sepa, $s_sepa) !== false) { $match = true; break; }
		}
		if (!$match) return;
	}
	if ($s_rapproche === 'non' && $f->nb_non_rapp === 0) return;
	if ($s_rapproche === 'oui' && ($f->nb_non_rapp > 0 || $f->nb_versements === 0)) return;
	$rows[] = $f;
};

foreach ($factures        as $f) { $_apply($f); }
foreach ($factures_client as $f) { $_apply($f); }

// ── Tri PHP ───────────────────────────────────────────────────────────────────
$php_sort_map = ['deja_paye' => 'deja_paye', 'restant' => 'restant', 'nb_versements' => 'nb_versements', 'nb_rapproche' => 'nb_rapproche'];
$sql_to_prop  = ['s.nom' => 'tiers_nom', 'f.ref' => 'fac_ref', 'f.total_ttc' => 'total_ttc'];

if (isset($php_sort_map[$sortfield])) {
    $prop = $php_sort_map[$sortfield]; $so = $sortorder;
    usort($rows, function($a, $b) use ($prop, $so) {
        $cmp = $a->$prop <=> $b->$prop;
        return $so === 'DESC' ? -$cmp : $cmp;
    });
} elseif ($type_facture === 'tous' && isset($sql_to_prop[$sortfield])) {
    // Deux listes SQL mergées → re-tri PHP
    $prop = $sql_to_prop[$sortfield]; $so = $sortorder;
    usort($rows, function($a, $b) use ($prop, $so) {
        $av = $a->$prop; $bv = $b->$prop;
        $cmp = ($prop === 'total_ttc') ? ((float)$av <=> (float)$bv) : strnatcasecmp((string)$av, (string)$bv);
        return $so === 'DESC' ? -$cmp : $cmp;
    });
}

// ── Stats ─────────────────────────────────────────────────────────────────────
$nb_factures   = count($rows);
$total_attendu = 0.0;
$total_paye    = 0.0;
$total_restant = 0.0;
$nb_vir_total  = 0;
$nb_vir_rapp   = 0;
foreach ($rows as $f) {
	$total_attendu += (float)$f->total_ttc;
	$total_paye    += $f->deja_paye;
	$total_restant += $f->restant;
	$nb_vir_total  += $f->nb_versements;
	$nb_vir_rapp   += $f->nb_rapproche;
}
$nb_vir_non = $nb_vir_total - $nb_vir_rapp;

// ── Export CSV ────────────────────────────────────────────────────────────────
if ($export === 'csv') {
	$filename = 'helpy_rapprochement_' . $annee . '.csv';
	header('Content-Type: text/csv; charset=UTF-8');
	header('Content-Disposition: attachment; filename="' . $filename . '"');
	header('Cache-Control: no-cache');
	echo "\xEF\xBB\xBF";

	echo implode(';', ['Type', 'Tiers', 'N° facture', 'Pack', 'Montant attendu (EUR)', 'Deja paye (EUR)', 'Restant (EUR)',
	                    'Date virement', 'Ref SEPA', 'Montant virement (EUR)', 'Releve bancaire', 'Rapproche']) . "\r\n";

	foreach ($rows as $f) {
		$packs = [];
		foreach ($f->packs as $pk) $packs[] = $pk->pack_label;
		$pack_str = implode(' / ', $packs);
		if (empty($f->payments)) continue;
		foreach ($f->payments as $p) {
			$date_p = $p->date_paiement ? date('d/m/Y', strtotime($p->date_paiement)) : '';
			$line = [
				$f->type === 'client' ? 'Client' : 'Fournisseur',
				$f->tiers_nom,
				$f->fac_ref,
				$pack_str,
				number_format((float)$f->total_ttc, 2, ',', ''),
				number_format((float)$f->deja_paye, 2, ',', ''),
				number_format((float)$f->restant, 2, ',', ''),
				$date_p,
				$p->ref_sepa,
				number_format((float)$p->montant_paye, 2, ',', ''),
				$p->num_releve,
				$p->rapproche ? 'Oui' : 'Non',
			];
			echo implode(';', array_map(fn($v) => '"' . str_replace('"', '""', (string)$v) . '"', $line)) . "\r\n";
		}
	}
	$db->close(); exit;
}

// ── Couleurs packs ────────────────────────────────────────────────────────────
$pack_colors = [
	'PACK-SANTE'      => '#0d6efd',
	'PACK-LUN'        => '#20c997',
	'PACK-NAIS'       => '#e83e8c',
	'PACK-SPORT'      => '#fd7e14',
	'HOSPI-18-20'     => '#6f42c1',
	'HOSPI-21-24'     => '#7952b3',
	'HOSPI-BEAU'      => '#8540c4',
	'HOSPI-BEAU-18'   => '#9b59b6',
	'HOSPI-BEAU-1820' => '#8540c4',
	'HOSPI-BEAU-ADU'  => '#6f42c1',
	'HOSPI-ENF-18'    => '#5a2d8c',
	'HOSPI-ENF-1920'  => '#7952b3',
	'HOSPI-AGT-2164'  => '#4a235a',
	'IND-FUN'         => '#343a40',
	'DEPART-PEN'      => '#6c757d',
];

// ── HTML ──────────────────────────────────────────────────────────────────────
llxHeader("", "Helpy — Rapprochement bancaire", '', '', 0, 0, '', '', '', 'mod-agebf page-compta');

print '
<style>
.bf-detail-row { display:none; }
.bf-detail-row.open { display:table-row; }
.bf-toggle-btn {
    cursor:pointer; border:none; background:none; padding:0 4px;
    color:#0d6efd; font-size:1.1em; line-height:1;
    transition: transform 0.15s;
}
.bf-toggle-btn.open { transform: rotate(90deg); }
.bf-detail-inner {
    background:#f8f9fa; border-left:3px solid #0d6efd;
    padding:8px 12px; border-radius:0 4px 4px 0;
}
.bf-pack-badge {
    display:inline-block; padding:1px 7px; border-radius:10px;
    font-size:0.78em; font-weight:bold; color:#fff; white-space:nowrap;
}
.bf-prog-wrap { background:#e9ecef; border-radius:6px; height:8px; width:90px; overflow:hidden; display:inline-block; vertical-align:middle; }
.bf-prog-bar  { background:#28a745; height:8px; }
</style>
<script>
function bfToggle(id) {
    var rows = document.querySelectorAll(".bf-det-" + id);
    var btn  = document.getElementById("bf-btn-" + id);
    var open = btn.classList.contains("open");
    rows.forEach(function(r) { r.classList.toggle("open", !open); });
    btn.classList.toggle("open", !open);
}
function bfToggleAll(openAll) {
    document.querySelectorAll(".bf-toggle-btn").forEach(function(btn) {
        var id = btn.id.replace("bf-btn-", "");
        document.querySelectorAll(".bf-det-" + id).forEach(function(r) { r.classList.toggle("open", openAll); });
        btn.classList.toggle("open", openAll);
    });
}
' . ($open_fac > 0 ? 'document.addEventListener("DOMContentLoaded", function() { var el = document.getElementById("fac-' . $open_fac . '"); if (el) el.scrollIntoView({block:"center"}); });' : '') . '
</script>
';

print load_fiche_titre("Rapprochement bancaire &mdash; paiements par facture", '', 'fa-exchange-alt');

// ── Fil du workflow ────────────────────────────────────────────────────────────
$url_packs = DOL_URL_ROOT . '/custom/agebf/agebf_packs.php';
print '<div style="display:flex;align-items:center;gap:8px;margin:2px 0 14px 0;font-size:0.88em">';
print '<a href="' . $url_packs . '" style="background:#eef3f8;color:#0e6fb5;border-radius:14px;padding:4px 12px;text-decoration:none;border:1px solid #bcd4ea">1. Paiements &agrave; effectuer</a>';
print '<span style="color:#999">&rarr;</span>';
print '<span style="background:#0e6fb5;color:#fff;border-radius:14px;padding:4px 12px;font-weight:bold">2. Rapprochement bancaire</span>';
print '</div>';

if ($msg_ok)  print '<div class="ok">'    . $msg_ok  . '</div>';
if ($msg_err) print '<div class="error">' . $msg_err . '</div>';

// ── Bandeau stats ─────────────────────────────────────────────────────────────
$stats = [
	['label' => 'Factures ' . $annee,    'value' => $nb_factures,                                   'color' => '#333'],
	['label' => 'Total attendu',         'value' => price($total_attendu) . '&nbsp;&euro;',          'color' => '#333'],
	['label' => 'D&eacute;j&agrave; pay&eacute;', 'value' => price($total_paye) . '&nbsp;&euro;',    'color' => '#28a745'],
	['label' => 'Restant',               'value' => price($total_restant) . '&nbsp;&euro;',          'color' => '#dc3545'],
	['label' => 'Virements &agrave; rapprocher', 'value' => $nb_vir_non,                             'color' => '#dc3545'],
	['label' => 'Virements rapproch&eacute;s',   'value' => $nb_vir_rapp,                            'color' => '#28a745'],
];
print '<div style="display:flex;flex-wrap:wrap;gap:10px;margin-bottom:16px">';
foreach ($stats as $st) {
	print '<div style="flex:1;min-width:120px;padding:10px 14px;background:#fff;border:1px solid #ddd;border-radius:6px;text-align:center;box-shadow:0 1px 3px rgba(0,0,0,.06)">';
	print '<div style="font-size:1.3em;font-weight:bold;color:' . $st['color'] . ';line-height:1.2">' . $st['value'] . '</div>';
	print '<div style="font-size:0.8em;color:#777;margin-top:3px">' . $st['label'] . '</div>';
	print '</div>';
}
print '</div>';

// ── Formulaire filtres ────────────────────────────────────────────────────────
print '<div class="fichecenter">';
print '<form method="GET" action="' . $url_base . '">';
print '<div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:12px">';

// Filtre année
print '<label style="font-weight:bold">Ann&eacute;e :</label>';
print '<select name="annee" onchange="this.form.submit()" style="padding:4px 8px;border-radius:3px;border:1px solid #ccc">';
for ($y = (int)date('Y') + 1; $y >= 2024; $y--) {
	print '<option value="' . $y . '"' . ($y === $annee ? ' selected' : '') . '>' . $y . '</option>';
}
print '</select>';

// Filtre type facture (NOUVEAU)
$type_lib = ['fournisseur' => 'Fournisseurs', 'client' => 'Clients', 'tous' => 'Toutes'];
print '<label style="font-weight:bold">Factures :</label>';
print '<select name="type_facture" onchange="this.form.submit()" style="padding:4px 8px;border-radius:3px;border:1px solid #ccc">';
foreach ($type_lib as $val => $lib) {
	print '<option value="' . $val . '"' . ($val === $type_facture ? ' selected' : '') . '>' . $lib . '</option>';
}
print '</select>';

// Filtre rapproché
$rapp_lib = ['tous' => 'Toutes', 'oui' => 'Enti&egrave;rement rapproch&eacute;es', 'non' => 'Avec virement &agrave; rapprocher'];
print '<label style="font-weight:bold">Rapproch&eacute; :</label>';
print '<select name="s_rapproche" onchange="this.form.submit()" style="padding:4px 8px;border-radius:3px;border:1px solid #ccc">';
foreach ($rapp_lib as $val => $lib) {
	print '<option value="' . $val . '"' . ($val === $s_rapproche ? ' selected' : '') . '>' . $lib . '</option>';
}
print '</select>';

// Filtre référence SEPA
print '<label style="font-weight:bold">R&eacute;f. SEPA :</label>';
print '<input type="text" name="s_sepa" value="' . dol_escape_htmltag($s_sepa) . '" placeholder="T250901..." '
    . 'style="padding:4px 8px;border-radius:3px;border:1px solid #ccc;width:130px">';
print '<button type="submit" style="padding:4px 12px;background:#0d6efd;color:#fff;border:none;border-radius:3px;cursor:pointer">Filtrer</button>';

if ($s_sepa !== '' || $s_rapproche !== 'tous') {
	print '<a href="' . $url_base . '?annee=' . $annee . '&type_facture=' . urlencode($type_facture) . '" style="padding:4px 12px;background:#dc3545;color:#fff;border-radius:3px;font-size:0.85em;text-decoration:none">&#x2715; Effacer</a>';
}

print '<button type="button" onclick="bfToggleAll(true)" style="padding:4px 10px;background:#6c757d;color:#fff;border:none;border-radius:3px;font-size:0.85em;cursor:pointer">D&eacute;plier tout</button>';
print '<button type="button" onclick="bfToggleAll(false)" style="padding:4px 10px;background:#6c757d;color:#fff;border:none;border-radius:3px;font-size:0.85em;cursor:pointer">Replier tout</button>';

print '<a href="' . $url_base . '?annee=' . $annee . '&s_rapproche=' . urlencode($s_rapproche)
    . '&s_sepa=' . urlencode($s_sepa) . '&type_facture=' . urlencode($type_facture) . '&export=csv" '
    . 'style="margin-left:auto;padding:4px 14px;background:#28a745;color:#fff;border-radius:3px;font-size:0.85em;text-decoration:none;display:inline-flex;align-items:center;gap:6px">'
    . img_picto('', 'fa-download', '') . ' Export CSV</a>';

print '</div>';
print '</form>';

// ── Bouton import relevé Belfius (fournisseurs uniquement) ────────────────────
if ($type_facture !== 'client') {
	print '<form method="POST" action="' . $url_base . '" enctype="multipart/form-data" style="display:flex;align-items:center;gap:8px;margin-bottom:16px;padding:10px 14px;background:#eef4ff;border:1px solid #cfe0ff;border-radius:6px">';
	print '<input type="hidden" name="token"  value="' . newToken() . '">';
	print '<input type="hidden" name="action" value="import_belfius">';
	print '<input type="hidden" name="annee"  value="' . $annee . '">';
	print '<label style="font-weight:bold;color:#0d4dad">' . img_picto('', 'fa-university', '') . ' Rapprochement automatique &mdash; importer le relev&eacute; Belfius (CSV) :</label>';
	print '<input type="file" name="belfius_file" accept=".csv,text/csv" required style="font-size:0.85em">';
	print '<button type="submit" style="padding:5px 14px;background:#0d6efd;color:#fff;border:none;border-radius:3px;cursor:pointer;white-space:nowrap">' . img_picto('', 'fa-upload', '') . ' Analyser le relev&eacute;</button>';
	print '</form>';
}

// ── Écran de validation de l'import Belfius ──────────────────────────────────
if ($action === 'import_belfius') {
	$parsed = null;
	if (isset($_FILES['belfius_file']) && $_FILES['belfius_file']['error'] === UPLOAD_ERR_OK) {
		$parsed = bf_parse_belfius($_FILES['belfius_file']['tmp_name']);
	}
	if (empty($parsed)) {
		print '<div class="error">Impossible de lire le fichier, ou aucune transaction trouv&eacute;e. V&eacute;rifiez que c\'est bien un export CSV Belfius.</div>';
		print '<a href="' . $url_base . '?annee=' . $annee . '" style="padding:5px 14px;background:#6c757d;color:#fff;border-radius:3px;text-decoration:none">&laquo; Retour</a>';
		llxFooter(); $db->close(); exit;
	}

	$lots = bf_load_lots($db);

	$byct = [];
	foreach ($lots as $L) { if (!empty($L->ct_num)) $byct[(int) $L->ct_num] = $L; }

	$matches = []; $cnt = ['exact' => 0, 'sur' => 0, 'probable' => 0, 'ambigu' => 0, 'nomatch' => 0];
	foreach ($parsed as $line) {
		$confiance = 'nomatch'; $lot = null;
		if (!empty($line['ct']) && isset($byct[(int) $line['ct']])) {
			$lot = $byct[(int) $line['ct']];
			$confiance = 'exact';
		} else {
			$cands = [];
			foreach ($lots as $L) {
				if (abs($L->total - $line['montant']) <= 0.01) $cands[] = $L;
			}
			if (count($cands) === 1) {
				$lot = $cands[0];
				$confiance = bf_date_close($lot->date_op, $line['date_iso']) ? 'sur' : 'probable';
			} elseif (count($cands) > 1) {
				$byd = [];
				foreach ($cands as $L) { if (bf_date_close($L->date_op, $line['date_iso'])) $byd[] = $L; }
				if (count($byd) === 1) { $lot = $byd[0]; $confiance = 'probable'; }
				else                   { $lot = $cands[0]; $confiance = 'ambigu'; }
			}
		}
		$cnt[$confiance]++;
		$matches[] = ['line' => $line, 'lot' => $lot, 'conf' => $confiance];
	}

	$badge = [
		'exact'    => '<span style="color:#1a7f37;font-weight:bold">' . img_picto('', 'fa-check-double', '') . ' S&ucirc;r (r&eacute;f. SEPA)</span>',
		'sur'      => '<span style="color:#28a745;font-weight:bold">' . img_picto('', 'fa-check-circle', '') . ' S&ucirc;r (montant + date)</span>',
		'probable' => '<span style="color:#fd7e14;font-weight:bold">' . img_picto('', 'fa-question-circle', '') . ' Probable (montant)</span>',
		'ambigu'   => '<span style="color:#dc3545;font-weight:bold">' . img_picto('', 'fa-exclamation-triangle', '') . ' Ambigu (plusieurs lots)</span>',
		'nomatch'  => '<span style="color:#999">&mdash; Aucun lot trouv&eacute;</span>',
	];

	print '<div style="background:#fff;border:1px solid #ddd;border-radius:6px;padding:14px;margin-bottom:16px">';
	print '<h3 style="margin:0 0 10px">' . img_picto('', 'fa-university', '') . ' V&eacute;rification du relev&eacute; Belfius &mdash; ' . count($matches) . ' ligne(s) de lot SEPA</h3>';
	print '<p style="margin:0 0 12px;color:#555">' . ($cnt['exact'] + $cnt['sur']) . ' s&ucirc;r(s)'
	    . ($cnt['exact'] > 0 ? ' (dont ' . $cnt['exact'] . ' par r&eacute;f. SEPA)' : '')
	    . ' &middot; ' . $cnt['probable'] . ' probable(s) &middot; <span style="color:#dc3545">' . $cnt['ambigu'] . ' ambigu(s)</span> &middot; ' . $cnt['nomatch'] . ' sans lot. '
	    . 'Chaque ligne du relev&eacute; est un <b>ordre collectif</b> regroupant plusieurs virements. '
	    . '<b>Coche les lots &agrave; rapprocher, d&eacute;plie le d&eacute;tail si besoin, puis valide.</b></p>';

	print '<form method="POST" action="' . $url_base . '">';
	print '<input type="hidden" name="token"  value="' . newToken() . '">';
	print '<input type="hidden" name="action" value="apply_belfius">';
	print '<input type="hidden" name="annee"  value="' . $annee . '">';

	print '<table class="noborder" style="width:100%;border-collapse:collapse">';
	print '<tr class="liste_titre">';
	print '<th style="text-align:center"><input type="checkbox" id="bf-chk-all" checked onclick="var a=this.checked;document.querySelectorAll(\'.bf-apply\').forEach(function(c){c.checked=a});"></th>';
	print '<th>Date</th><th>N&deg; extrait</th><th class="right">Montant global</th><th>Communication</th><th>Confiance</th><th>Lot SEPA &amp; virements</th>';
	print '</tr>';

	foreach ($matches as $idx => $mm) {
		$ln = $mm['line']; $confiance = $mm['conf']; $lot = $mm['lot'];
		$rowbg = ($confiance === 'ambigu') ? ' style="background:#fff5f5"' : (($confiance === 'nomatch') ? ' style="background:#f6f6f6;color:#999"' : '');
		print '<tr class="oddeven"' . $rowbg . '>';
		$can_apply = ($lot !== null && $lot->nb_libre > 0);
		print '<td style="text-align:center">';
		if ($can_apply) {
			$checked = ($confiance === 'exact' || $confiance === 'sur' || $confiance === 'probable') ? ' checked' : '';
			print '<input type="checkbox" class="bf-apply" name="apply[' . $idx . ']" value="1"' . $checked . '>';
		}
		print '</td>';
		print '<td style="white-space:nowrap">' . dol_escape_htmltag($ln['date_disp']) . '</td>';
		print '<td style="white-space:nowrap"><b>' . dol_escape_htmltag($ln['extrait']) . '</b></td>';
		print '<td class="right" style="white-space:nowrap;font-weight:bold">' . dol_escape_htmltag($ln['mont_disp']) . '&nbsp;&euro;</td>';
		print '<td style="font-size:0.85em;max-width:340px">' . dol_escape_htmltag($ln['comm']) . '</td>';
		print '<td style="white-space:nowrap">' . $badge[$confiance] . '</td>';
		print '<td>';
		print '<input type="hidden" name="sel_releve[' . $idx . ']" value="' . dol_escape_htmltag($ln['extrait']) . '">';
		if ($lot !== null) {
			print '<input type="hidden" name="sel_bon[' . $idx . ']" value="' . (int) $lot->bon_id . '">';
			$ecart = abs($lot->total - $ln['montant']);
			print '<div style="font-weight:600">' . dol_escape_htmltag($lot->ref) . ' <span style="color:#888;font-weight:normal">(bon #' . (int) $lot->bon_id . ')</span></div>';
			if ($confiance === 'exact' && !empty($lot->msgid)) {
				print '<div style="font-size:0.78em;color:#1a7f37">' . img_picto('', 'fa-link', '') . ' r&eacute;f. SEPA ' . dol_escape_htmltag($lot->msgid) . '</div>';
			}
			print '<div style="font-size:0.85em;color:#555">'
			    . $lot->nb . ' virement(s) &middot; total ' . price($lot->total) . '&nbsp;&euro;'
			    . ' &middot; lot du ' . dol_escape_htmltag($lot->date_op)
			    . ($ecart > 0.01 ? ' <span style="color:#dc3545">(&eacute;cart ' . price($ecart) . ' &euro;)</span>' : '')
			    . '</div>';
			if ($lot->nb_libre > 0) {
				print '<div style="font-size:0.85em;color:#0d4dad;font-weight:600">' . $lot->nb_libre . ' &agrave; rapprocher'
				    . ($lot->nb_rappro > 0 ? ' &middot; ' . $lot->nb_rappro . ' d&eacute;j&agrave; point&eacute;(s)' : '') . '</div>';
			} else {
				print '<div style="font-size:0.85em;color:#28a745;font-weight:600">' . img_picto('', 'fa-check-circle', '') . ' d&eacute;j&agrave; enti&egrave;rement rapproch&eacute;</div>';
			}
			print '<details style="margin-top:4px"><summary style="cursor:pointer;color:#0d6efd;font-size:0.82em">Voir le d&eacute;tail des ' . $lot->nb . ' virements</summary>';
			print '<table style="width:100%;border-collapse:collapse;font-size:0.82em;margin-top:4px">';
			foreach ($lot->virements as $v) {
				$st = $v->rappro
					? '<span style="color:#28a745">' . img_picto('', 'fa-check', '') . '</span>'
					: '<span style="color:#dc3545">' . img_picto('', 'fa-times', '') . '</span>';
				print '<tr style="border-bottom:1px solid #eee">'
				    . '<td style="padding:2px 6px">' . $st . '</td>'
				    . '<td style="padding:2px 6px">' . dol_escape_htmltag($v->fac_ref) . '</td>'
				    . '<td style="padding:2px 6px">' . dol_escape_htmltag($v->tiers) . '</td>'
				    . '<td style="padding:2px 6px;text-align:right">' . price($v->montant) . '&nbsp;&euro;</td>'
				    . '</tr>';
			}
			print '</table></details>';
		} else {
			print '<span style="color:#999">aucun lot SEPA &agrave; ce montant / cette r&eacute;f&eacute;rence</span>';
		}
		print '</td>';
		print '</tr>';
	}
	print '</table>';
	print '<div style="margin-top:14px;display:flex;gap:10px">';
	print '<button type="submit" style="padding:7px 18px;background:#28a745;color:#fff;border:none;border-radius:3px;cursor:pointer;font-weight:bold">' . img_picto('', 'fa-check', '') . ' Valider et rapprocher les lots coch&eacute;s</button>';
	print '<a href="' . $url_base . '?annee=' . $annee . '" style="padding:7px 18px;background:#6c757d;color:#fff;border-radius:3px;text-decoration:none">Annuler</a>';
	print '</div>';
	print '</form>';
	print '</div>';

	llxFooter(); $db->close(); exit;
}

// ── Tableau (1 ligne par facture) ─────────────────────────────────────────────
print '<table class="noborder centpercent">';
print '<tr class="liste_titre">';
print '<th style="width:28px"></th>';
print '<th>'     . compta_sort_link('Tiers',           's.nom',       $sortfield, $sortorder, $url_base, $annee, $s_rapproche, $s_sepa, $type_facture) . '</th>';
print '<th>'     . compta_sort_link('Facture / Pack',  'f.ref',       $sortfield, $sortorder, $url_base, $annee, $s_rapproche, $s_sepa, $type_facture) . '</th>';
print '<th class="right">' . compta_sort_link('Montant attendu', 'f.total_ttc', $sortfield, $sortorder, $url_base, $annee, $s_rapproche, $s_sepa, $type_facture) . '</th>';
print '<th class="right">' . compta_sort_link('D&eacute;j&agrave; pay&eacute;', 'deja_paye',     $sortfield, $sortorder, $url_base, $annee, $s_rapproche, $s_sepa, $type_facture) . '</th>';
print '<th class="right">' . compta_sort_link('Restant',                        'restant',       $sortfield, $sortorder, $url_base, $annee, $s_rapproche, $s_sepa, $type_facture) . '</th>';
print '<th class="center">' . compta_sort_link('Virements',                     'nb_versements', $sortfield, $sortorder, $url_base, $annee, $s_rapproche, $s_sepa, $type_facture) . '</th>';
print '<th class="center">' . compta_sort_link('Rapprochement',                 'nb_rapproche',  $sortfield, $sortorder, $url_base, $annee, $s_rapproche, $s_sepa, $type_facture) . '</th>';
print '</tr>';

if (empty($rows)) {
	print '<tr class="oddeven"><td colspan="8" class="center opacitymedium" style="padding:20px">Aucune facture trouv&eacute;e.</td></tr>';
}

foreach ($rows as $f) {
	$fid = (int)$f->fac_id;

	$is_solde = ($f->restant < 0.01);
	$statut_paie = $is_solde
		? '<span style="color:#28a745;font-weight:bold">Sold&eacute;e</span>'
		: '<span style="color:#fd7e14;font-weight:bold">Partielle</span>';

	if ($f->nb_versements > 0 && $f->nb_non_rapp === 0) {
		$rapp_cell = '<span style="color:#28a745;font-weight:bold">' . img_picto('', 'fa-check-circle', '') . ' ' . $f->nb_rapproche . '/' . $f->nb_versements . '</span>';
	} else {
		$rapp_cell = '<span style="color:#dc3545;font-weight:bold">' . img_picto('', 'fa-times-circle', '') . ' ' . $f->nb_rapproche . '/' . $f->nb_versements . '</span>';
	}

	$pack_html = '';
	foreach ($f->packs as $pk) {
		$pack_color = $pack_colors[$pk->pack_ref] ?? '#6c757d';
		$pack_html .= '<span class="bf-pack-badge" style="background:' . $pack_color . ';margin-right:4px">'
		            . dol_escape_htmltag($pk->pack_label) . '</span>';
	}

	// Badge type (visible seulement quand filtre = Toutes)
	$type_badge = '';
	if ($type_facture === 'tous') {
		if ($f->type === 'client') {
			$type_badge = '<span style="background:#0d6efd;color:#fff;font-size:0.7em;padding:1px 5px;border-radius:8px;vertical-align:middle;margin-right:3px">Client</span>';
		} else {
			$type_badge = '<span style="background:#fd7e14;color:#fff;font-size:0.7em;padding:1px 5px;border-radius:8px;vertical-align:middle;margin-right:3px">Fourn.</span>';
		}
	}

	// URLs selon type de facture
	$fac_url  = ($f->type === 'client')
		? DOL_URL_ROOT . '/compta/facture/card.php?facid=' . $fid
		: DOL_URL_ROOT . '/fourn/facture/card.php?facid=' . $fid;
	$fac_link   = '<a href="' . $fac_url . '" style="color:#0d6efd;font-weight:600">' . $type_badge . dol_escape_htmltag($f->fac_ref) . '</a>';
	$tiers_link = '<a href="' . DOL_URL_ROOT . '/societe/card.php?socid=' . (int)$f->soc_id . '">' . dol_escape_htmltag($f->tiers_nom) . '</a>';

	$pct  = ((float)$f->total_ttc > 0) ? min(100, round($f->deja_paye / (float)$f->total_ttc * 100)) : 0;
	$prog = '<span class="bf-prog-wrap" title="' . $pct . '% pay&eacute;"><span class="bf-prog-bar" style="width:' . $pct . '%"></span></span>';

	$bg = ($f->nb_non_rapp > 0) ? ' style="background-color:#fff5f5"' : '';
	$is_open  = ($open_fac === $fid);
	$open_cls = $is_open ? ' open' : '';

	print '<tr class="oddeven"' . $bg . ' id="fac-' . $fid . '-' . $f->type . '">';
	print '<td style="text-align:center;padding:6px 4px">';
	if (!empty($f->payments)) {
		$btn_id = $fid . '_' . $f->type;
		print '<button type="button" id="bf-btn-' . $btn_id . '" class="bf-toggle-btn' . $open_cls . '" onclick="bfToggle(\'' . $btn_id . '\')" title="Voir les virements">&#9658;</button>';
	}
	print '</td>';
	print '<td>' . $tiers_link . '</td>';
	print '<td>' . $fac_link . '<div style="margin-top:3px">' . $pack_html . '</div></td>';
	print '<td class="right" style="white-space:nowrap">' . price($f->total_ttc) . '&nbsp;&euro;</td>';
	print '<td class="right" style="white-space:nowrap;color:#28a745;font-weight:600">' . price($f->deja_paye) . '&nbsp;&euro;<br>' . $prog . '</td>';
	print '<td class="right" style="white-space:nowrap;font-weight:bold;color:' . ($is_solde ? '#28a745' : '#dc3545') . '">' . price($f->restant) . '&nbsp;&euro;</td>';
	print '<td class="center"><span style="font-weight:bold">' . (int)$f->nb_versements . '</span><div style="font-size:0.8em">' . $statut_paie . '</div></td>';
	print '<td class="center" style="white-space:nowrap">' . $rapp_cell . '</td>';
	print '</tr>';

	if (!empty($f->payments)) {
		$btn_id = $fid . '_' . $f->type;
		print '<tr class="bf-detail-row bf-det-' . $btn_id . $open_cls . '"' . $bg . '>';
		print '<td colspan="8" style="padding:0 16px 12px 36px' . ($f->nb_non_rapp > 0 ? ';background-color:#fff5f5' : '') . '">';
		print '<div class="bf-detail-inner">';
		print '<table style="width:100%;border-collapse:collapse;font-size:0.9em">';
		print '<tr style="color:#666;border-bottom:1px solid #ddd">';
		print '<th style="text-align:left;padding:4px 8px;font-weight:600">Date</th>';
		print '<th style="text-align:left;padding:4px 8px;font-weight:600">R&eacute;f. paiement</th>';
		print '<th style="text-align:right;padding:4px 8px;font-weight:600">Montant vers&eacute;</th>';
		print '<th style="text-align:left;padding:4px 8px;font-weight:600">Relev&eacute; bancaire</th>';
		print '<th style="text-align:center;padding:4px 8px;font-weight:600">Rapproch&eacute;</th>';
		print '<th style="text-align:left;padding:4px 8px;font-weight:600">Action</th>';
		print '</tr>';

		foreach ($f->payments as $p) {
			$pid = (int)$p->pay_id;

			if ($p->ref_sepa !== '') {
				$sepa_txt  = '<span style="font-family:monospace;font-weight:600">' . dol_escape_htmltag($p->ref_sepa) . '</span>';
				$sepa_cell = ($p->bank_id > 0)
					? '<a href="' . DOL_URL_ROOT . '/compta/bank/line.php?rowid=' . (int)$p->bank_id . '" target="_blank" style="color:#0d6efd;text-decoration:none">' . $sepa_txt . '</a>'
					: $sepa_txt;
			} else {
				$sepa_cell = '<span style="color:#aaa">—</span>';
			}

			$has_releve  = ($p->rapproche && $p->num_releve !== '' && $p->num_releve !== $p->ref_sepa);
			$releve_cell = $has_releve
				? '<a href="' . DOL_URL_ROOT . '/compta/bank/bankentries_list.php?account=2&search_num_releve='
				  . urlencode($p->num_releve) . '" target="_blank" style="color:#0d6efd">'
				  . dol_escape_htmltag($p->num_releve) . '</a>'
				: '<span style="color:#aaa">—</span>';

			$pbadge = $p->rapproche
				? '<span style="color:#28a745;font-weight:bold">' . img_picto('', 'fa-check-circle', '') . ' Oui</span>'
				: '<span style="color:#dc3545;font-weight:bold">' . img_picto('', 'fa-times-circle', '') . ' Non</span>';

			// Lien fiche paiement selon type
			$pay_url  = ($f->type === 'client')
				? DOL_URL_ROOT . '/compta/paiement/card.php?id=' . $pid
				: DOL_URL_ROOT . '/fourn/paiement/card.php?id=' . $pid;
			$fiche_btn = '<a href="' . $pay_url . '" style="padding:2px 8px;background:#6c757d;color:#fff;border-radius:3px;font-size:0.8em;text-decoration:none;display:inline-flex;align-items:center;gap:4px;margin-right:6px">'
			           . img_picto('', 'fa-eye', '') . ' Fiche</a>';

			if (!$p->rapproche) {
				$action_html = '<form method="POST" action="' . $url_base . '" style="display:inline-flex;align-items:center;gap:5px">'
				           . '<input type="hidden" name="action"       value="rapprocher">'
				           . '<input type="hidden" name="token"        value="' . newToken() . '">'
				           . '<input type="hidden" name="pay_id"       value="' . $pid . '">'
				           . '<input type="hidden" name="fac_id"       value="' . $fid . '">'
				           . '<input type="hidden" name="pay_type"     value="' . dol_escape_htmltag($f->type) . '">'
				           . '<input type="hidden" name="annee"        value="' . $annee . '">'
				           . '<input type="hidden" name="s_rapproche"  value="' . dol_escape_htmltag($s_rapproche) . '">'
				           . '<input type="hidden" name="s_sepa"       value="' . dol_escape_htmltag($s_sepa) . '">'
				           . '<input type="hidden" name="type_facture" value="' . dol_escape_htmltag($type_facture) . '">'
				           . '<input type="text"   name="num_releve" placeholder="Ex: Belfius 8/32" '
				           .        'style="width:130px;padding:2px 6px;font-size:0.82em;border:1px solid #ccc;border-radius:3px">'
				           . '<button type="submit" style="padding:2px 10px;background:#28a745;color:#fff;border:none;border-radius:3px;font-size:0.82em;cursor:pointer;white-space:nowrap">'
				           . img_picto('', 'fa-check', '') . ' Rapprocher</button>'
				           . '</form>';
			} else {
				$action_html = '';
				if ($user->admin) {
					$action_html = '<form method="POST" action="' . $url_base . '" style="display:inline-flex;align-items:center" '
					           . 'onsubmit="return confirm(\'Annuler le rapprochement de ce virement ?\')">'
					           . '<input type="hidden" name="action"       value="derapprocher">'
					           . '<input type="hidden" name="token"        value="' . newToken() . '">'
					           . '<input type="hidden" name="pay_id"       value="' . $pid . '">'
					           . '<input type="hidden" name="fac_id"       value="' . $fid . '">'
					           . '<input type="hidden" name="pay_type"     value="' . dol_escape_htmltag($f->type) . '">'
					           . '<input type="hidden" name="annee"        value="' . $annee . '">'
					           . '<input type="hidden" name="s_rapproche"  value="' . dol_escape_htmltag($s_rapproche) . '">'
					           . '<input type="hidden" name="s_sepa"       value="' . dol_escape_htmltag($s_sepa) . '">'
					           . '<input type="hidden" name="type_facture" value="' . dol_escape_htmltag($type_facture) . '">'
					           . '<button type="submit" style="padding:2px 9px;background:#dc3545;color:#fff;border:none;border-radius:3px;font-size:0.78em;cursor:pointer;white-space:nowrap">'
					           . img_picto('', 'fa-undo', '') . ' Ann.</button>'
					           . '</form>';
				}
			}

			print '<tr style="border-bottom:1px solid #eee">';
			print '<td style="padding:5px 8px;white-space:nowrap">' . dol_print_date($db->jdate($p->date_paiement), 'day') . '</td>';
			print '<td style="padding:5px 8px">' . $sepa_cell . '</td>';
			print '<td style="padding:5px 8px;text-align:right;font-weight:bold;white-space:nowrap">' . price($p->montant_paye) . '&nbsp;&euro;</td>';
			print '<td style="padding:5px 8px">' . $releve_cell . '</td>';
			print '<td style="padding:5px 8px;text-align:center">' . $pbadge . '</td>';
			print '<td style="padding:5px 8px;white-space:nowrap">' . $fiche_btn . $action_html . '</td>';
			print '</tr>';
		}

		print '</table>';
		print '</div>';
		print '</td></tr>';
	}
}

print '</table>';

print '<div style="margin-top:14px;font-size:0.85em;color:#666;display:flex;gap:18px;flex-wrap:wrap;align-items:center">';
print '<b>L&eacute;gende :</b>';
print '<span>Colonne <b>Rapprochement</b> = nombre de virements rapproch&eacute;s / total des virements de la facture</span>';
print '<span>&#9658; = d&eacute;plier les virements de la facture pour les rapprocher un par un</span>';
print '<span>' . img_picto('', 'fa-times-circle', 'style="color:#dc3545"') . ' Non rapproch&eacute; = saisir le n&deg; relev&eacute; Belfius puis cliquer <b>Rapprocher</b></span>';
if ($user->admin) {
    print '<span style="color:#dc3545">Bouton <b>Ann.</b> (admin uniquement) = annuler un rapprochement</span>';
}
print '</div>';

print '</div>'; // fichecenter

llxFooter();
$db->close();
